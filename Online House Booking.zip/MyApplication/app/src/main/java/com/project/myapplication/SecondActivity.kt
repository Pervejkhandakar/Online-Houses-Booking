package com.project.myapplication

import android.annotation.SuppressLint
import android.content.ClipData.Item
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)
      val scrollView = findViewById<ScrollView>(R.id.metext1)

        val textView2 = findViewById<TextView>(R.id.textView2)
          val   textView3 = findViewById<ImageView>(R.id.textView3)
        val   textView4 = findViewById<ImageView>(R.id.image1)
        val   textView5 = findViewById<ImageView>(R.id.image2)
        val   textView6 = findViewById<ImageView>(R.id.image3)
        val   textView7 = findViewById<ImageView>(R.id.image7)



        // 1111111  Example: Set a click listener on a TextView


        textView3.setOnClickListener {
            val intent = Intent(this, Item1::class.java)
            intent.putExtra("EXTRA_MESSAGE", "Hello from MainActivity!") // Optional: Pass data
            startActivity(intent)
        }



        textView4.setOnClickListener {
            val intent = Intent(this, Item1::class.java)
            intent.putExtra("EXTRA_MESSAGE", "Hello from MainActivity!") // Optional: Pass data
            startActivity(intent)
        }


        textView5.setOnClickListener {
            val intent = Intent(this, item2::class.java)
            intent.putExtra("EXTRA_MESSAGE", "Hello from MainActivity!") // Optional: Pass data
            startActivity(intent)
        }


        textView6.setOnClickListener {
            val intent = Intent(this, item3::class.java)
            intent.putExtra("EXTRA_MESSAGE", "Hello from MainActivity!") // Optional: Pass data
            startActivity(intent)
        }



        textView7.setOnClickListener {
            val intent = Intent(this, item4::class.java)
            intent.putExtra("EXTRA_MESSAGE", "Hello from MainActivity!") // Optional: Pass data
            startActivity(intent)
        }



        textView2.setOnClickListener {
            textView2.text = "The Nationwide House Price Index and Halifax House Price Index use Hedonic regression (also known as the characteristics based method) using their own datasets compiled from their mortgage lending. These indices have a longer time-series than the Governmental HPIs"
        }
    }
}
